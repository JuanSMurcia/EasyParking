# Smart-parking
Smart parking portal is a parking guidance and reservation system in towns.
Looking for spaces to park can be really hectic in busy town in regard to 
walking distance to your destination from your vehicle, safety of the vehicle,
 payment for the service among others. If one happens to be a stranger in town 
 it gets more difficult to operate around the town. The system solves all this 
 parking cycle issues.
