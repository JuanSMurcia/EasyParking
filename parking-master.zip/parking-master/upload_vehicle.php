<?php
require 'mysqlConnect.php';
?>
<?php
if(isset($_POST['sub'])){
	$tipo=mysqli_real_escape_string($con,$_POST['tipo']);
	$placas=mysqli_real_escape_string($con,$_POST['placas']);
	$date_exit=date('0000-00-00 00:00:00');

	   if($tipo==''&& $placas==''){
		echo"<script>alert('please fill all field')</script>";
		echo"<script>window.open('blank.php','_self')</script>";
		exit();
	 }

	else{

		$insert="INSERT INTO `vehicle` (`id`, `tipo`, `placas`,`date_exit` ) VALUES (NULL, '$tipo', '$placas','$date_exit');";
		$run_insert=mysqli_query($con,$insert);
		if($run_insert){

			echo"<script>window.open('register_vehicle.php','_self')</script>";

		}
		else{
			echo"<script>alert('Error intentar de nuevo!')</script>";
			echo"<script>window.open('register_vehicle.php','_self')</script>";
		}
}}

?>
