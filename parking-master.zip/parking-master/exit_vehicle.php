<?php
require 'mysqlConnect.php';
?>
<?php
if(isset($_POST['custId'])){
	$exit_id=mysqli_real_escape_string($con,$_POST['custId']);

		$insert="UPDATE `vehicle` SET date_exit = now() WHERE id = '$exit_id'";
		$run_insert=mysqli_query($con,$insert);



		/*$resul= "SELECT TIMESTAMPDIFF(MINUTE, `date_enter`, `date_exit`) AS 'minutos_transcurridos' FROM `vehicle` WHERE id = '$exit_id'";*/
		$resul= "SELECT `date_enter`, `date_exit`,`tipo`  FROM `vehicle` WHERE id = '$exit_id'";
		$run_resul = mysqli_query($con, $resul);

		$row = mysqli_fetch_array($run_resul);
		
		$entrada = $row['date_enter'];
		$salida = $row['date_exit'];
		$tipo = $row['tipo'];

		/*$pass_entrada = strtotime($entrada);
		$pass_salida = strtotime($salida);*/
		 
		
		$minutos = (strtotime($entrada)-strtotime($salida))/60;
		$minutos = abs($minutos); $minutos = floor($minutos);

		$resul_tipo = "SELECT `cost` FROM `type` WHERE `vehiculo_tipo` = '$tipo'";
		$run_resul_tipo = mysqli_query($con, $resul_tipo);

		$price = mysqli_fetch_array($run_resul_tipo);

		$cost = $price['cost'];

	
		if($run_resul){

			if($minutos > 30){
				$precio_por_minuto = $cost / $minutos;
				$precio_total = $precio_por_minuto * $minutos;

				$insert_price="UPDATE `vehicle` SET cost = $precio_total WHERE id = '$exit_id'";
				$run_insert_price=mysqli_query($con,$insert_price);

				if($run_insert_price){
					echo"<script>alert('Vehiculo liquidado')</script>";
					echo"<script>window.open('register_vehicle.php','_self')</script>";
				}


			}else{

				$insert_price="UPDATE `vehicle` SET cost = $cost WHERE id = '$exit_id'";
				$run_insert_price=mysqli_query($con,$insert_price);

				if($run_insert_price){
					echo"<script>alert('Vehiculo liquidado')</script>";
					echo"<script>window.open('register_vehicle.php','_self')</script>";
				}

				
			}
		
			/*echo"<script>alert("")</script>";
			echo"<script>window.open('register_vehicle.php','_self')</script>";*/

		}

}
?>





